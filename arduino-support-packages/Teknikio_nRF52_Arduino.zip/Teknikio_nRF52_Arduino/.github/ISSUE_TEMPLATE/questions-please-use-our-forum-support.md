---
name: Questions please use our forum support
about: Don't open issue, post your question at forums.adafruit.com
title: ''
labels: wontfix
assignees: ''

---

**Please DO NOT use GitHub issues for question or troubleshooting projects.**  Instead use the forums at http://forums.adafruit.com. Only create issue if it is a bug, feature  or discussion that requires **code changes to resolve**.

**Check our tutorial and examples** There is chance that our tutorial and examples has useful information for you:
- [Feather nRF52832 tutorial](https://learn.adafruit.com/bluefruit-nrf52-feather-learning-guide) 
- [Feather nRF52840 tutorial](https://learn.adafruit.com/introducing-the-adafruit-nrf52840-feather)
