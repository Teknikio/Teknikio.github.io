# Bluebird nRF52 Arduino Core Changelog

## 0.15.0 - 2020.03.27

- First release validated